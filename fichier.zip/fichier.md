# Site
Commande script : 
wget -qO- https://raw.githubusercontent.com/Rxdy/Site/refs/heads/main/script.sh | bash


http://www.tux-planet.fr/connaitre-la-version-de-linux-installe/
https://github.com/runtipi/runtipi/tree/develop/scripts
https://www.it-connect.fr/mettre-le-resultat-dune-commande-dans-une-variable/
https://forum.ubuntu-fr.org/viewtopic.php?id=324110
https://fr.linux-console.net/?p=29605
https://fr.linux-console.net/?p=29567
